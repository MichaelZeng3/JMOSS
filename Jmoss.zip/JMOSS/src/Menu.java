
public class Menu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ScanInfo s = new ScanInfo();
		s.scaninput(0);
		s.printemail();
	}

}
